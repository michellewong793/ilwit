import React from "react";
import "./styles.css";
import Box from "./Box.js";
import Container from "./container.js";

export default function App() {
  return (
    <div className="App">
      <h1>I love women in tech</h1>
      <Container />
    </div>
  );
}
